#ifndef MAKE_FILES_H
#define MAKE_FILES_H

int generar();
#include "make_files.h"
#endif